import { AveragePipe } from './average.pipe';

describe('AveragePipe', () => {
  it('create an instance', () => {
    const pipe = new AveragePipe();
    expect(pipe).toBeTruthy();
  });
});
